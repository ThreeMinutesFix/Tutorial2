<?php  
// TMDB API key  
$apiKey = '2bca77a6dcb0c892cd1d4b677768fa88';  
// <!--urlFormat-->
// <!--https://tutorials.threeminutesfix.in/movies.php?movieSlug=Inception-->
// Define the constant to control deep link redirection
define('DEEPLINK_REDIRECT', false); // Set to true to enable redirect, false to disable

// Extract the movie slug and ID from the URL  
$movieSlug = $_GET['movieSlug'] ?? null;  
$movieId = $_GET['movieId'] ?? null;  

// Initialize variables for movie details  
$movieName = "Movie Not Found";  
$movieBanner = '';  
$movieDescription = "No description available.";  
$errorMsg = '';  

// Fetch movie details from TMDB using search by name  
if ($movieSlug) {  
   // Use the search API to find a movie by name, URL encoding the query to handle special characters  
   $searchUrl = "https://api.themoviedb.org/3/search/movie?api_key={$apiKey}&query=" . urlencode($movieSlug) . "&language=en-US";  

   // Use cURL for better error handling  
   $ch = curl_init();  
   curl_setopt($ch, CURLOPT_URL, $searchUrl);  
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
   $response = curl_exec($ch);  
   $curlError = curl_error($ch); // Capture any cURL error  
   curl_close($ch);  

   // Check if the response was successful  
   if ($response === false) {  
      $errorMsg = "Error fetching data from TMDB: $curlError";  
   } else {  
      $searchData = json_decode($response, true);  
      if (json_last_error() !== JSON_ERROR_NONE) {  
        $errorMsg = "Error parsing JSON response.";  
      } elseif ($searchData && isset($searchData['results'][0])) {  
        $movieData = $searchData['results'][0]; // Get the first movie in the search results  
        $movieName = $movieData['title'] ?? 'Movie Not Found';  
        $movieBanner = "https://image.tmdb.org/t/p/w500" . ($movieData['poster_path'] ?? '');  
        $movieDescription = $movieData['overview'] ?? 'No description available.';  
      } else {  
        $errorMsg = "No movies found with the name '{$movieSlug}'.";  
      }  
   }  
} else {  
   $errorMsg = "Movie name is missing in the URL.";  
}  

// Construct a valid URL for Open Graph and ensure no trailing slashes or unnecessary params
$movieUrl = "https://tutorials.threeminutesfix.in/movies/" . urlencode($movieSlug);

// Check if deep link redirection is enabled and handle accordingly
if (DEEPLINK_REDIRECT) {
    // Redirect to the main download page, not the movie-specific download page
    header("Location: https://tutorials.threeminutesfix.in/download.html");
    exit;  // Always call exit after a redirect to stop further execution of the script
}

?>  

<!DOCTYPE html>  
<html lang="en">  
<head>  
   <meta charset="UTF-8">  
   <meta name="viewport" content="width=device-width, initial-scale=1.0">  
   <meta property="og:title" content="<?= htmlspecialchars($movieName) ?>">  
   <meta property="og:image" content="<?= htmlspecialchars($movieBanner) ?>">  
   <meta property="og:description" content="<?= htmlspecialchars($movieDescription) ?>">  
   <meta property="og:url" content="<?= htmlspecialchars($movieUrl) ?>">  
   <meta property="og:type" content="video.movie">  
   <title><?= htmlspecialchars($movieName) ?></title>  
   <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700&display=swap">  
   <style>  
      body {  
        font-family: 'Open Sans', sans-serif;  
        margin: 0;  
        padding: 0;  
        background-color: #f0f0f0;  
      }  
      .container {  
        max-width: 800px;  
        margin: 40px auto;  
        padding: 20px;  
        background-color: #fff;  
        border: 1px solid #ddd;  
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);  
      }  
      .movie-poster {  
        width: 100%;  
        height: 400px;  
        object-fit: cover;  
        border-radius: 10px 10px 0 0;  
      }  
      .movie-info {  
        padding: 20px;  
      }  
      .movie-title {  
        font-size: 24px;  
        font-weight: bold;  
        margin-bottom: 10px;  
      }  
      .movie-description {  
        font-size: 16px;  
        color: #666;  
      }  
      .error-message {  
        color: red;  
        font-size: 18px;  
        font-weight: bold;  
        margin-bottom: 20px;  
      }  
   </style>  
</head>  
<body>  
   <div class="container">  
      <?php if ($movieBanner): ?>  
        <img src="<?= htmlspecialchars($movieBanner) ?>" alt="<?= htmlspecialchars($movieName) ?>" class="movie-poster">  
      <?php else: ?>  
        <p>No image available.</p>  
      <?php endif; ?>  
      <div class="movie-info">  
        <h1 class="movie-title"><?= htmlspecialchars($movieName) ?></h1>  
        <p class="movie-description"><?= htmlspecialchars($movieDescription) ?></p>  
      </div>  
      <?php if ($errorMsg): ?>  
        <p class="error-message"><?= htmlspecialchars($errorMsg) ?></p>  
      <?php endif; ?>  
   </div>  
</body>  
</html>

