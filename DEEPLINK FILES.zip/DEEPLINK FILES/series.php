<?php  
// TMDB API key  
$apiKey = '2bca77a6dcb0c892cd1d4b677768fa88';  
// Define the constant to control deep link redirection
define('DEEPLINK_REDIRECT', false); // Set to true to enable redirect, false to disable

// Extract the series slug and ID from the URL  
$seriesSlug = $_GET['movieSlug'] ?? null;  
$seriesId = $_GET['id'] ?? null;  
//https://tutorials.threeminutesfix.in/series.php?movieSlug=loki&id=12345
// Initialize variables for series details  
$seriesName = "Series Not Found";  
$seriesBanner = '';  
$seriesDescription = "No description available.";  
$errorMsg = '';  

// Fetch series details from TMDB using search by name  
if ($seriesSlug) {  
   // Use the search API to find a series by name, URL encoding the query to handle special characters  
   $searchUrl = "https://api.themoviedb.org/3/search/tv?api_key={$apiKey}&query=" . urlencode($seriesSlug) . "&language=en-US";  

   // Use cURL for better error handling  
   $ch = curl_init();  
   curl_setopt($ch, CURLOPT_URL, $searchUrl);  
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
   $response = curl_exec($ch);  
   $curlError = curl_error($ch); // Capture any cURL error  
   curl_close($ch);  

   // Check if the response was successful  
   if ($response === false) {  
      $errorMsg = "Error fetching data from TMDB: $curlError";  
   } else {  
      $searchData = json_decode($response, true);  
      if (json_last_error() !== JSON_ERROR_NONE) {  
        $errorMsg = "Error parsing JSON response.";  
      } elseif ($searchData && isset($searchData['results'][0])) {  
        $seriesData = $searchData['results'][0]; // Get the first series in the search results  
        $seriesName = $seriesData['name'] ?? 'Series Not Found';  
        $seriesBanner = "https://image.tmdb.org/t/p/w500" . ($seriesData['poster_path'] ?? '');  
        $seriesDescription = $seriesData['overview'] ?? 'No description available.';  
      } else {  
        $errorMsg = "No series found with the name '{$seriesSlug}'.";  
      }  
   }  
} else {  
   $errorMsg = "Series name is missing in the URL.";  
}  

// Construct a valid URL for Open Graph and ensure no trailing slashes or unnecessary params
$seriesUrl = "https://tutorials.threeminutesfix.in/series/" . urlencode($seriesSlug);

// Check if deep link redirection is enabled and handle accordingly
if (DEEPLINK_REDIRECT) {
    // Redirect to the main download page, not the series-specific download page
    header("Location: https://tutorials.threeminutesfix.in/download.html");
    exit;  // Always call exit after a redirect to stop further execution of the script
}

?>  

<!DOCTYPE html>  
<html lang="en">  
<head>  
   <meta charset="UTF-8">  
   <meta name="viewport" content="width=device-width, initial-scale=1.0">  
   <meta property="og:title" content="<?= htmlspecialchars($seriesName) ?>">  
   <meta property="og:image" content="<?= htmlspecialchars($seriesBanner) ?>">  
   <meta property="og:description" content="<?= htmlspecialchars($seriesDescription) ?>">  
   <meta property="og:url" content="<?= htmlspecialchars($seriesUrl) ?>">  
   <meta property="og:type" content="video.tv_show">  
   <title><?= htmlspecialchars($seriesName) ?></title>  
   <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700&display=swap">  
   <style>  
      body {  
        font-family: 'Open Sans', sans-serif;  
        margin: 0;  
        padding: 0;  
        background-color: #f0f0f0;  
      }  
      .container {  
        max-width: 800px;  
        margin: 40px auto;  
        padding: 20px;  
        background-color: #fff;  
        border: 1px solid #ddd;  
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);  
      }  
      .series-poster {  
        width: 100%;  
        height: 400px;  
        object-fit: cover;  
        border-radius: 10px 10px 0 0;  
      }  
      .series-info {  
        padding: 20px;  
      }  
      .series-title {  
        font-size: 24px;  
        font-weight: bold;  
        margin-bottom: 10px;  
      }  
      .series-description {  
        font-size: 16px;  
        color: #666;  
      }  
      .error-message {  
        color: red;  
        font-size: 18px;  
        font-weight: bold;  
        margin-bottom: 20px;  
      }  
   </style>  
</head>  
<body>  
   <div class="container">  
      <?php if ($seriesBanner): ?>  
        <img src="<?= htmlspecialchars($seriesBanner) ?>" alt="<?= htmlspecialchars($seriesName) ?>" class="series-poster">  
      <?php else: ?>  
        <p>No image available.</p>  
      <?php endif; ?>  
      <div class="series-info">  
        <h1 class="series-title"><?= htmlspecialchars($seriesName) ?></h1>  
        <p class="series-description"><?= htmlspecialchars($seriesDescription) ?></p>  
      </div>  
      <?php if ($errorMsg): ?>  
        <p class="error-message"><?= htmlspecialchars($errorMsg) ?></p>  
      <?php endif; ?>  
   </div>  
</body>  
</html>
